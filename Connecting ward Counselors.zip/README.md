# connect-councillor
A system where people will be able to contract councillor of their respective area. Using this system people can post their issue and will be able to see update directy from councillors.
